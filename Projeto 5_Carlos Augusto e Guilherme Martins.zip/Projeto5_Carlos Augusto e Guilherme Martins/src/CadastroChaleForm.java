import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class CadastroChaleForm extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private JTextField txtLocalizacao;
    private JTextField txtCapacidade;
    private JTextField txtValorAltaEstacao;
    private JTextField txtValorBaixaEstacao;
    private JButton btnCadastrar;

    public CadastroChaleForm() {
        setTitle("Cadastro de Chalé");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        txtLocalizacao = new JTextField(20);
        txtCapacidade = new JTextField(20);
        txtValorAltaEstacao = new JTextField(20);
        txtValorBaixaEstacao = new JTextField(20);

        panel.add(new JLabel("Localização:"));
        panel.add(txtLocalizacao);
        panel.add(new JLabel("Capacidade:"));
        panel.add(txtCapacidade);
        panel.add(new JLabel("Valor Alta Estação:"));
        panel.add(txtValorAltaEstacao);
        panel.add(new JLabel("Valor Baixa Estação:"));
        panel.add(txtValorBaixaEstacao);

        btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarChale();
            }
        });

        panel.add(btnCadastrar);
        add(panel);
        setVisible(true);
    }

    private void cadastrarChale() {
        try {
            // Obtenha os valores dos campos de texto e crie um objeto Chale
            String localizacao = txtLocalizacao.getText();
            int capacidade = Integer.parseInt(txtCapacidade.getText());
            double valorAltaEstacao = Double.parseDouble(txtValorAltaEstacao.getText());
            double valorBaixaEstacao = Double.parseDouble(txtValorBaixaEstacao.getText());
            int codChale = 0;
            
            Chale chale = new Chale();
			chale.setCodChale(codChale);
            chale.setLocalizacao(localizacao);
            chale.setCapacidade(capacidade);
            chale.setValorAltaEstacao(valorAltaEstacao);
            chale.setValorBaixaEstacao(valorBaixaEstacao);

            // Chamar o DAO para inserir o chalé
            ChaleDAO chaleDAO = new ChaleDAO();
            chaleDAO.inserir(chale);

            JOptionPane.showMessageDialog(this, "Chalé cadastrado com sucesso!");
            if(chale != null) {
            	codChale++;
            	JOptionPane.showMessageDialog(this, "Código do chalé: "+ codChale);
            }
            
            limparCampos();
        } catch (SQLException se) {
            JOptionPane.showMessageDialog(this, "Erro ao cadastrar chalé: " + se.getMessage());
        }
    }

    private void limparCampos() {
        txtLocalizacao.setText("");
        txtCapacidade.setText("");
        txtValorAltaEstacao.setText("");
        txtValorBaixaEstacao.setText("");
    }

  /*  public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CadastroChaleForm();
            }
        });
    }*/
}
