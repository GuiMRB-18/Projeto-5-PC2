import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CadastroClienteForm extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtNome;
    private JTextField txtRG;
    private JTextField txtEndereco;
    private JTextField txtBairro;
    private JTextField txtCidade;
    private JTextField txtEstado;
    private JTextField txtCEP;
    private JTextField txtNascimento;
    private JButton btnCadastrar;

    public CadastroClienteForm() {
        setTitle("Cadastro de Cliente");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        txtNome = new JTextField(20);
        txtRG = new JTextField(20);
        txtEndereco = new JTextField(20);
        txtBairro = new JTextField(20);
        txtCidade = new JTextField(20);
        txtEstado = new JTextField(20);
        txtCEP = new JTextField(20);
        txtNascimento = new JTextField(20);

        panel.add(new JLabel("Nome:"));
        panel.add(txtNome);
        panel.add(new JLabel("RG:"));
        panel.add(txtRG);
        panel.add(new JLabel("Endereço:"));
        panel.add(txtEndereco);
        panel.add(new JLabel("Bairro:"));
        panel.add(txtBairro);
        panel.add(new JLabel("Cidade:"));
        panel.add(txtCidade);
        panel.add(new JLabel("Estado:"));
        panel.add(txtEstado);
        panel.add(new JLabel("CEP:"));
        panel.add(txtCEP);
        panel.add(new JLabel("Data de Nascimento (dd/MM/yyyy):"));
        panel.add(txtNascimento);

        btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarCliente();
            }
        });

        panel.add(btnCadastrar);
        add(panel);
        setVisible(true);
    }

    private void cadastrarCliente() {
        try {
            // Obter os valores dos campos de texto e criar um objeto Cliente
            String nome = txtNome.getText();
            String rg = txtRG.getText();
            String endereco = txtEndereco.getText();
            String bairro = txtBairro.getText();
            String cidade = txtCidade.getText();
            String estado = txtEstado.getText();
            String cep = txtCEP.getText();
            Date nascimento = new SimpleDateFormat("dd/MM/yyyy").parse(txtNascimento.getText());
            int codCliente = 0;
            
            Cliente cliente = new Cliente();
            cliente.setCodCliente(codCliente);
            cliente.setNomeCliente(nome);
            cliente.setRgCliente(rg);
            cliente.setEnderecoCliente(endereco);
            cliente.setBairroCliente(bairro);
            cliente.setCidadeCliente(cidade);
            cliente.setEstadoCliente(estado);
            cliente.setCepCliente(cep);
            cliente.setNascimentoCliente(nascimento);

            // Chamar o DAO para inserir o cliente
            ClienteDAO clienteDAO = new ClienteDAO();
            clienteDAO.inserir(cliente);

            JOptionPane.showMessageDialog(this, "Cliente cadastrado com sucesso!");
            if(cliente != null) {
            	codCliente++;
            	JOptionPane.showMessageDialog(this, "Código do cliente: "+ codCliente);
            }
            
            limparCampos();
        } catch (ParseException pe) {
            JOptionPane.showMessageDialog(this, "Data de nascimento inválida.");
        } catch (SQLException se) {
            JOptionPane.showMessageDialog(this, "Erro ao cadastrar cliente: " + se.getMessage());
        }
    }

    private void limparCampos() {
        txtNome.setText("");
        txtRG.setText("");
        txtEndereco.setText("");
        txtBairro.setText("");
        txtCidade.setText("");
        txtEstado.setText("");
        txtCEP.setText("");
        txtNascimento.setText("");
    }

    /*public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CadastroClienteForm();
            }
        });
    }*/
}
