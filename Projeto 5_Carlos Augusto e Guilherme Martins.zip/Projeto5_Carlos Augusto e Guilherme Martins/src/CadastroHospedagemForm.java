import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CadastroHospedagemForm extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtCodChale;
	private JTextField txtCodCliente;
    private JTextField txtEstado;
    private JTextField txtDataInicio;
    private JTextField txtDataFim;
    private JTextField txtQtdPessoas;
    private JTextField txtDesconto;
    private JTextField txtValorFinal;
    private JButton btnCadastrar;

    public CadastroHospedagemForm() {
        setTitle("Cadastro de Hospedagem");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        txtCodChale = new JTextField(20);
        txtCodCliente = new JTextField(20);
        txtEstado = new JTextField(20);
        txtDataInicio = new JTextField(20);
        txtDataFim = new JTextField(20);
        txtQtdPessoas = new JTextField(20);
        txtDesconto = new JTextField(20);
        txtValorFinal = new JTextField(20);

        panel.add(new JLabel("Código do Chalé:"));
        panel.add(txtCodChale);
        panel.add(new JLabel("Código do Cliente:"));
        panel.add(txtCodCliente);
        panel.add(new JLabel("Estado:"));
        panel.add(txtEstado);
        panel.add(new JLabel("Data de Início (dd/MM/yyyy):"));
        panel.add(txtDataInicio);
        panel.add(new JLabel("Data de Fim (dd/MM/yyyy):"));
        panel.add(txtDataFim);
        panel.add(new JLabel("Quantidade de Pessoas:"));
        panel.add(txtQtdPessoas);
        panel.add(new JLabel("Desconto:"));
        panel.add(txtDesconto);
        panel.add(new JLabel("Valor Final:"));
        panel.add(txtValorFinal);

        btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarHospedagem();
            }
        });

        panel.add(btnCadastrar);
        add(panel);
        setVisible(true);
    }

    private void cadastrarHospedagem() {
        try {
            // Obtenha os valores dos campos de texto e crie um objeto Hospedagem
            int codChale = Integer.parseInt(txtCodChale.getText());
            int codCliente = Integer.parseInt(txtCodCliente.getText());
            String estado = txtEstado.getText();
            Date dataInicio = new SimpleDateFormat("dd/MM/yyyy").parse(txtDataInicio.getText());
            Date dataFim = new SimpleDateFormat("dd/MM/yyyy").parse(txtDataFim.getText());
            int qtdPessoas = Integer.parseInt(txtQtdPessoas.getText());
            double desconto = Double.parseDouble(txtDesconto.getText());
            double valorFinal = Double.parseDouble(txtValorFinal.getText());

            Hospedagem hospedagem = new Hospedagem();
            hospedagem.setCodChale(codChale);
            hospedagem.setCodCliente(codCliente);
            hospedagem.setEstado(estado);
            hospedagem.setDataInicio(dataInicio);
            hospedagem.setDataFim(dataFim);
            hospedagem.setQtdPessoas(qtdPessoas);
            hospedagem.setDesconto(desconto);
            hospedagem.setValorFinal(valorFinal);

            // Chamar o DAO para inserir a hospedagem
            HospedagemDAO hospedagemDAO = new HospedagemDAO();
            hospedagemDAO.inserir(hospedagem);

            JOptionPane.showMessageDialog(this, "Hospedagem cadastrada com sucesso!");
            limparCampos();
        } catch (ParseException pe) {
            JOptionPane.showMessageDialog(this, "Data inválida.");
        } catch (SQLException se) {
            JOptionPane.showMessageDialog(this, "Erro ao cadastrar hospedagem: " + se.getMessage());
        }
    }

    private void limparCampos() {
        txtCodChale.setText("");
        txtCodCliente.setText("");
        txtEstado.setText("");
        txtDataInicio.setText("");
        txtDataFim.setText("");
        txtQtdPessoas.setText("");
        txtDesconto.setText("");
        txtValorFinal.setText("");
    }

    /*public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CadastroHospedagemForm();
            }
        });
    }*/
}
