import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    private static final String URL = "jdbc:mysql://localhost:3306/sua_base_de_dados";
    private static final String USER = "root";  // Seu usuário
    private static final String PASSWORD = "sua_senha";  // Sua senha

    public static Connection getConnection() throws SQLException {
       
    	java.sql.Connection connection = null;
    	try {
        	Class.forName("org.postgresql.Driver");	
			connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres","postgres","1903");
			
			if(connection != null) {
				System.out.println("OK");
			} else {
				System.out.println("ERRO");
			}
        } catch (ClassNotFoundException | SQLException e) {
            throw new SQLException("Erro ao conectar ao banco de dados: " + e.getMessage());
        }
		return connection;
    }

	public static String getUrl() {
		return URL;
	}

	public static String getUser() {
		return USER;
	}

	public static String getPassword() {
		return PASSWORD;
	}
}
