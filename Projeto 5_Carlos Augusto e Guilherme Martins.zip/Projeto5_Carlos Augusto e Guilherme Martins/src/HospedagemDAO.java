import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class HospedagemDAO {

    public void inserir(Hospedagem hospedagem) throws SQLException {
        String sql = "INSERT INTO Hospedagem (codChale, codCliente, estado, dataInicio, dataFim, qtdPessoas, desconto, valorFinal) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, hospedagem.getCodChale());
            stmt.setInt(2, hospedagem.getCodCliente());
            stmt.setString(3, hospedagem.getEstado());
            stmt.setDate(4, new java.sql.Date(hospedagem.getDataInicio().getTime()));
            stmt.setDate(5, new java.sql.Date(hospedagem.getDataFim().getTime()));
            stmt.setInt(6, hospedagem.getQtdPessoas());
            stmt.setDouble(7, hospedagem.getDesconto());
            stmt.setDouble(8, hospedagem.getValorFinal());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new SQLException("Erro ao inserir hospedagem: " + e.getMessage());
        }
    }
}
