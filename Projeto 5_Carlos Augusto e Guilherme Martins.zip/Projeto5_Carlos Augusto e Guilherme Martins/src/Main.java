import javax.swing.SwingUtilities;

public class Main {

	public static void main(String[] args) {
		
		 SwingUtilities.invokeLater(new Runnable() {
	            @Override
	            public void run() {
	                new CadastroClienteForm();
	            }
	        });
		 
		 SwingUtilities.invokeLater(new Runnable() {
	            @Override
	            public void run() {
	                new CadastroChaleForm();
	            }
	        });
		 
	        SwingUtilities.invokeLater(new Runnable() {
	            @Override
	            public void run() {
	                new CadastroHospedagemForm();
	            }
	        });

	}

}
