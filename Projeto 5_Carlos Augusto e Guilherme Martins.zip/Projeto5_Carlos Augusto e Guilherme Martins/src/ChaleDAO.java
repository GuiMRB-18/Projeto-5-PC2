import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ChaleDAO {

    public void inserir(Chale chale) throws SQLException {
        String sql = "INSERT INTO Chale (localizacao, capacidade, valorAltaEstacao, valorBaixaEstacao) VALUES (?, ?, ?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
        	
            stmt.setString(1, chale.getLocalizacao());
            stmt.setInt(2, chale.getCapacidade());
            stmt.setDouble(3, chale.getValorAltaEstacao());
            stmt.setDouble(4, chale.getValorBaixaEstacao());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new SQLException("Erro ao inserir chale: " + e.getMessage());
        }
    }
}
