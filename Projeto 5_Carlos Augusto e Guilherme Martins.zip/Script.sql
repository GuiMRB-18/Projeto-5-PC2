create table Chale(
codChale SERIAL PRIMARY KEY,
localizacao varchar not null,
capacidade integer not null,
valorAltaEstacao float not null,
valorBaixaEstacao float not null
);
create table Cliente(
codCliente SERIAL PRIMARY KEY,
nomeCliente varchar not null,
rgCliente varchar not null,
enderecoCliente varchar not null,
bairroCliente varchar not null,
cidadeCliente varchar not null,
estadoCliente varchar not null,
cepCliente varchar not null,
nascimentoCliente date not null
);
create table Hospedagem(
codHospedagem SERIAL PRIMARY KEY,
codChale INTEGER NOT NULL, 
codCliente INTEGER NOT NULL,  
estado VARCHAR NOT NULL,
dataInicio DATE NOT NULL,
dataFim DATE NOT NULL,
qtdPessoas INTEGER NOT NULL,
desconto FLOAT NOT NULL,
valorFinal FLOAT NOT NULL,
FOREIGN KEY (codChale) REFERENCES Chale(codChale),
FOREIGN KEY (codCliente) REFERENCES Cliente(codCliente)
);